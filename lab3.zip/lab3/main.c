/*
 * main.c
 *
 *  Created on: Sep 8, 2023
 *      Author: cddudley
 */
#include "movement.h"
#include "cyBot_uart.h"
#include "cyBot_Scan.h"
#include "Timer.h"
#include "lcd.h"


void main() {

    oi_t *sensor_data = oi_alloc();
    timer_init();
    lcd_init();
    int init = 7;
    cyBot_uart_init();
    cyBOT_init_Scan(init);
    cyBOT_SERVRO_cal_t calibration = cyBOT_SERVO_cal();

    right_calibration_value = calibration.right;
    left_calibration_value = calibration.left;

    cyBOT_Scan_t data;


    int message = cyBot_getByte();

    if (message == 'm') {
        char toprint[50];
        char string[] = "\rDegrees\t\tDistance(cm)\n";

        int i = 0;
        while(i < strlen(string)){
            cyBot_sendByte(string[i]);
            i++;
        }

        int angle;
        for (angle = 0; angle <= 180; angle += 2) {
            cyBOT_Scan(angle, &data);

            sprintf(toprint, "\r%d\t\t%.1f\n", angle, data.sound_dist);
            i = 0;
            while(i < strlen(toprint)){
                cyBot_sendByte(toprint[i]);
                i++;
            }
        }

    }
//      }
//      lcd_putc(cyBot_getByte());
//
//    cyBot_sendByte(m);

    oi_free(sensor_data);
}
